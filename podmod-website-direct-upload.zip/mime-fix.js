// PodMod Website - Client-side MIME type fixing and URL normalization
document.addEventListener("DOMContentLoaded", function() {
  // Fix MIME types for CSS and JavaScript files
  function detectAndFixMimeIssues() {
    console.log("PodMod MIME fix: Running automatic check");
    
    // Fix CSS files
    const cssLinks = document.querySelectorAll('link[rel="stylesheet"]');
    cssLinks.forEach(link => {
      const newLink = document.createElement('link');
      newLink.rel = 'stylesheet';
      newLink.type = 'text/css';
      newLink.href = link.getAttribute('href');
      link.parentNode.replaceChild(newLink, link);
    });
    
    // Fix JavaScript files
    const scriptTags = document.querySelectorAll('script[src]');
    scriptTags.forEach(script => {
      if (script.getAttribute('data-fixed') === 'true') return;
      
      const newScript = document.createElement('script');
      newScript.type = 'text/javascript';
      newScript.src = script.getAttribute('src');
      newScript.setAttribute('data-fixed', 'true');
      script.parentNode.replaceChild(newScript, script);
    });
    
    console.log("PodMod MIME fix: Applying content type fixes");
  }
  
  // Normalize URLs (remove .html extensions for consistency)
  function normalizeUrls() {
    const currentPath = window.location.pathname;
    
    // Redirect .html URLs to their clean counterparts
    if (currentPath.endsWith('.html')) {
      const cleanPath = currentPath.replace(/\.html$/, '');
      window.history.replaceState({}, document.title, cleanPath);
    }
    
    // Fix links in the document
    const links = document.querySelectorAll('a[href]');
    links.forEach(link => {
      const href = link.getAttribute('href');
      
      // Only process internal links
      if (href.startsWith('/') || href.startsWith('./') || href.startsWith('../')) {
        // Replace .html extension with /
        if (href.endsWith('.html')) {
          const newHref = href.replace(/\.html$/, '');
          link.setAttribute('href', newHref);
        }
      }
    });
  }
  
  // Run MIME fixes immediately and after a delay
  detectAndFixMimeIssues();
  setTimeout(detectAndFixMimeIssues, 500);
  
  // Normalize URLs
  normalizeUrls();
});
