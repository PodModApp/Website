// Particle Wave Animation
document.addEventListener('DOMContentLoaded', function() {
  // Apply particles only to the hero/banner section
  const heroSection = document.querySelector('.hero');
  
  if (heroSection) {
    createParticles(heroSection, {
      color: 'rgba(255, 255, 255, 0.3)',
      count: 35,
      speed: 0.5,
      size: 3,
      wave: true
    });
  }

  // Function to create and animate particles
  function createParticles(container, options) {
    // Create a canvas element
    const canvas = document.createElement('canvas');
    canvas.classList.add('particles-canvas');
    
    // Style the canvas
    canvas.style.position = 'absolute';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.pointerEvents = 'none';
    canvas.style.zIndex = '1';
    
    // Add the canvas as the first child of the container
    if (container.firstChild) {
      container.insertBefore(canvas, container.firstChild);
    } else {
      container.appendChild(canvas);
    }
    
    // Set canvas dimensions
    const setCanvasDimensions = () => {
      canvas.width = container.offsetWidth;
      canvas.height = container.offsetHeight;
    };
    
    // Set initial dimensions
    setCanvasDimensions();
    
    // Update canvas dimensions on window resize
    window.addEventListener('resize', setCanvasDimensions);
    
    // Get the context for drawing
    const ctx = canvas.getContext('2d');
    
    // Particle class
    class Particle {
      constructor() {
        this.reset();
      }
      
      reset() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.size = Math.random() * options.size + 1;
        this.speed = Math.random() * options.speed + 0.1;
        this.angle = Math.random() * Math.PI * 2;
        this.opacity = Math.random() * 0.5 + 0.2;
        this.waveOffset = Math.random() * Math.PI * 2;
      }
      
      update(time) {
        if (options.wave) {
          this.y += Math.sin(time / 1000 + this.waveOffset) * 0.5;
          this.x += this.speed * Math.cos(this.angle);
        } else {
          this.x += this.speed * Math.cos(this.angle);
          this.y += this.speed * Math.sin(this.angle);
        }
        
        // If particle is out of bounds, reset it
        if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) {
          this.reset();
        }
      }
      
      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = options.color.replace(')', ', ' + this.opacity + ')');
        ctx.fill();
      }
    }
    
    // Create particles
    const particles = [];
    for (let i = 0; i < options.count; i++) {
      particles.push(new Particle());
    }
    
    // Animation loop
    let animationId;
    const animate = (time) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particles.forEach(particle => {
        particle.update(time);
        particle.draw();
      });
      
      // Draw subtle connecting lines between nearby particles
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance < 100) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            const opacity = 0.1 * (1 - distance / 100);
            ctx.strokeStyle = options.color.replace(')', ', ' + opacity + ')');
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }
      
      animationId = requestAnimationFrame(animate);
    };
    
    // Start animation
    animate(0);
    
    // Cleanup function
    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', setCanvasDimensions);
      container.removeChild(canvas);
    };
  }
});