// Simple fade-in animation for sections
document.addEventListener('DOMContentLoaded', function() {
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
    
    // Handle about navigation from any page
    document.querySelectorAll('.about-nav-link').forEach(aboutLink => {
        aboutLink.addEventListener('click', function(e) {
            // If we're not on the homepage, navigate to homepage first
            if (window.location.pathname !== '/' && window.location.pathname !== '/index.html') {
                window.location.href = '/#about';
            } else {
                // If we're already on homepage, just scroll
                e.preventDefault();
                document.querySelector('#about').scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
});