# PODMOD Static Website

This is a static website for PODMOD, an AI-enhanced podcasting tool.

## Deployment to Cloudflare Pages

### Option 1: Direct Upload via Cloudflare Dashboard

1. Log in to your Cloudflare account
2. Navigate to "Pages" in the dashboard
3. Click "Create a project" and select "Direct Upload"
4. Upload the contents of this folder
5. Configure your deployment settings:
   - Production branch: main (or your preferred branch)
   - Build settings: Leave empty as this is a static site
   - Root directory: Leave as default (/)
6. Click "Save and Deploy"

### Option 2: Deployment via GitHub

1. Create a GitHub repository
2. Push the contents of this folder to your repository
3. Log in to your Cloudflare account
4. Navigate to "Pages" in the dashboard
5. Click "Create a project" and select "Connect to Git"
6. Connect to your GitHub account and select your repository
7. Configure your deployment settings:
   - Production branch: main (or your preferred branch)
   - Build settings: Leave empty as this is a static site
   - Root directory: Leave as default (/)
8. Click "Save and Deploy"

## File Structure

```
/
├── index.html         # Homepage
├── about.html         # About page
├── 404.html           # Error page with redirect
├── images/            # Image assets including logo
├── css/               # CSS stylesheets
└── js/                # JavaScript files
```

## Custom Domain Setup (Optional)

1. In your Cloudflare Pages project, go to "Custom domains"
2. Click "Set up a custom domain"
3. Enter your domain name and follow the instructions
4. Update your DNS settings as instructed by Cloudflare

## Maintenance

To update the website:
1. Make changes to the HTML, CSS, or JavaScript files
2. If using direct upload, upload the files again through the Cloudflare dashboard
3. If using GitHub, commit and push your changes to trigger automatic deployment